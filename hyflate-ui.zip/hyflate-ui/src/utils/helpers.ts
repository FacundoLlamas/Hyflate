import {
  NoEthereumProviderError,
  UserRejectedRequestError as UserRejectedRequestErrorInjected,
} from '@web3-react/injected-connector'
import { UnsupportedChainIdError } from '@web3-react/core'

export function getErrorMessage(error: any | undefined): string {
  if (error instanceof NoEthereumProviderError) {
    return 'No Ethereum browser extension detected, install MetaMask on desktop or visit from a dApp browser on mobile.'
  } else if (error instanceof UnsupportedChainIdError) {
    return "You're connected to an unsupported network."
  } else if (error instanceof UserRejectedRequestErrorInjected) {
    return 'Please authorize this website to access your Ethereum account.'
  } else {
    console.error(error)
    return 'An unknown error occurred. Please reload page.'
  }
}

export const hashShortener = (hash: string) => {
  return `${hash.substring(0, 6)}...${hash.substring(
    hash.length - 4
  )}`.toLowerCase()
}
