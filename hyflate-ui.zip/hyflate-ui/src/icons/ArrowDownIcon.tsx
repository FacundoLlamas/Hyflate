import React from 'react'

const ArrowDownIcon = ({ className }: { className?: string }) => {
  return (
    <svg
      className={`${className} arrow-down`}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <path
        id="Path-2"
        data-name="Path"
        d="M9.462.292l-3.88,3.88L1.7.292A1,1,0,0,0,.292,1.7l4.59,4.59a1,1,0,0,0,1.41,0l4.59-4.59a1,1,0,0,0,0-1.41,1.017,1.017,0,0,0-1.42,0Z"
        transform="translate(6.418 8.998)"
        fill="#141029"
      ></path>
    </svg>
  )
}

export default ArrowDownIcon
