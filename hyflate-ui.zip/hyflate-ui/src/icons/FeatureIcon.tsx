import React from "react";

const FeatureIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="29.547"
      height="29.547"
      viewBox="0 0 29.547 29.547"
    >
      <path
        id="shape"
        d="M5.328,29.547C1.859,29.547,0,27.7,0,24.25V5.281C0,1.844,1.859,0,5.328,0H24.2c3.485,0,5.344,1.844,5.344,5.281V24.25c0,3.438-1.859,5.3-5.344,5.3Z"
        fill="#fff"
      />
    </svg>
  );
};

export default FeatureIcon;
