import React from "react";

const MessageIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 20 20"
    >
      <g id="message" opacity="0.4">
        <path id="frame" d="M0,0H20V20H0Z" fill="none" />
        <path
          id="shape"
          d="M2.441,13.487A15.358,15.358,0,0,0,3.487,11.86,6.083,6.083,0,0,1,0,6.514C0,2.905,3.589,0,8.067,0S16.14,2.905,16.14,6.514c0,3.719-3.637,6.549-8.51,6.494a10.187,10.187,0,0,1-4.4,1.976A.906.906,0,0,1,2.441,13.487Z"
          transform="translate(1.93 2.675)"
          fill="#141029"
        />
      </g>
    </svg>
  );
};

export default MessageIcon;
