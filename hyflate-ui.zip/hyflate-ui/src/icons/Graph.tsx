import React from 'react'

const Graph = () => {
  return (
    <>
      <svg
        className="w-100"
        xmlns="http://www.w3.org/2000/svg"
        width="443.5"
        height="321"
        viewBox="0 0 443.5 321"
      >
        <g id="Group_16" data-name="Group 16" transform="translate(0 4)">
          <text
            id="caption"
            transform="translate(9 57)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="-6.469" y="0">
              5
            </tspan>
          </text>
          <text
            id="caption_copy_6"
            data-name="caption copy 6"
            transform="translate(9 9)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="-6.469" y="0">
              6
            </tspan>
          </text>
          <text
            id="caption_copy"
            data-name="caption copy"
            transform="translate(9 105)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="-6.469" y="0">
              4
            </tspan>
          </text>
          <text
            id="caption_copy_2"
            data-name="caption copy 2"
            transform="translate(9 153)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="-6.469" y="0">
              3
            </tspan>
          </text>
          <text
            id="caption_copy_3"
            data-name="caption copy 3"
            transform="translate(9 201)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="-6.469" y="0">
              2
            </tspan>
          </text>
          <text
            id="caption_copy_4"
            data-name="caption copy 4"
            transform="translate(8 249)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="-6.469" y="0">
              1
            </tspan>
          </text>
          <text
            id="caption_copy_5"
            data-name="caption copy 5"
            transform="translate(0 297)"
            fill="#140129"
            fontSize="12"
            fontFamily="SegoeUI, Segoe UI"
            letterSpacing="0.083em"
            opacity="0.6"
          >
            <tspan x="0" y="0">
              0
            </tspan>
          </text>
          <g id="Group_8" data-name="Group 8" transform="translate(9 305)">
            <text
              id="caption_copy_5-2"
              data-name="caption copy 5"
              transform="translate(0 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                01-Jan
              </tspan>
            </text>
            <text
              id="caption_copy_7"
              data-name="caption copy 7"
              transform="translate(63 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                02-Jan
              </tspan>
            </text>
            <text
              id="caption_copy_8"
              data-name="caption copy 8"
              transform="translate(128 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                03-Jan
              </tspan>
            </text>
            <text
              id="caption_copy_9"
              data-name="caption copy 9"
              transform="translate(193 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                04-Jan
              </tspan>
            </text>
            <text
              id="caption_copy_10"
              data-name="caption copy 10"
              transform="translate(259 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                05-Jan
              </tspan>
            </text>
            <text
              id="caption_copy_11"
              data-name="caption copy 11"
              transform="translate(324 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                06-Jan
              </tspan>
            </text>
            <text
              id="caption_copy_12"
              data-name="caption copy 12"
              transform="translate(389 9)"
              fill="#140129"
              fontSize="12"
              fontFamily="SegoeUI, Segoe UI"
              letterSpacing="0.083em"
              opacity="0.6"
            >
              <tspan x="0" y="0">
                07-Jan
              </tspan>
            </text>
          </g>
          <path
            id="Line"
            d="M0,.5H426"
            transform="translate(17 296.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
          <path
            id="Line_Copy"
            data-name="Line Copy"
            d="M0,.5H426"
            transform="translate(17 248.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
          <path
            id="Line_Copy_3"
            data-name="Line Copy 3"
            d="M0,.5H426"
            transform="translate(17 200.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
          <path
            id="Line_Copy_2"
            data-name="Line Copy 2"
            d="M0,.5H426"
            transform="translate(17 152.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
          <path
            id="Line_Copy_5"
            data-name="Line Copy 5"
            d="M0,.5H426"
            transform="translate(17 104.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
          <path
            id="Line_Copy_4"
            data-name="Line Copy 4"
            d="M0,.5H426"
            transform="translate(17 56.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
          <path
            id="Line_Copy_6"
            data-name="Line Copy 6"
            d="M0,.5H426"
            transform="translate(17 8.5)"
            fill="none"
            stroke="rgba(20,1,41,0.06)"
            stroke-linecap="square"
            stroke-miterlimit="10"
            stroke-width="1"
          />
        </g>
        <path
          id="Line_2"
          data-name="Line 2"
          d="M0,0,56,115l65-57.5,48.318,58L258.946,15.038,308.635,71.2H381.5"
          transform="translate(39.5 68.5)"
          fill="none"
          stroke="#16b8b8"
          stroke-linecap="square"
          stroke-miterlimit="10"
          stroke-width="2"
        />
      </svg>
    </>
  )
}

export default Graph
