import React from "react";

const MinusIcon = () => {
  return (
    <svg
      className="minus-icon"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g id="minus" opacity="0.4">
        <rect id="frame" width="24" height="24" fill="none" />
        <path
          id="shape"
          d="M12.2,2.078a1.046,1.046,0,0,0,1.023-1.039A1.051,1.051,0,0,0,12.2,0H1.023A1.062,1.062,0,0,0,0,1.039,1.056,1.056,0,0,0,1.023,2.078Z"
          transform="translate(5.387 11.328)"
          fill="#141029"
        />
      </g>
    </svg>
  );
};

export default MinusIcon;
