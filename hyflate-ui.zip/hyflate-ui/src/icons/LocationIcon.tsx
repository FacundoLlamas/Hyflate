import React from "react";

const LocationIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 20 20"
    >
      <g id="location" opacity="0.4">
        <path id="frame" d="M0,0H20V20H0Z" fill="none" />
        <path
          id="shape"
          d="M6.611,12.729,6.6,7.923c0-.109-.041-.15-.15-.15L1.641,7.759C.718,7.759,0,7.478,0,6.713,0,6.057.622,5.681,1.278,5.38L12.442.246A2.281,2.281,0,0,1,13.358,0a1,1,0,0,1,1.012,1.012,2.215,2.215,0,0,1-.247.909L8.982,13.09c-.314.677-.683,1.272-1.333,1.272C6.877,14.362,6.611,13.624,6.611,12.729Z"
          transform="translate(2.306 3.058)"
          fill="#141029"
        />
      </g>
    </svg>
  );
};

export default LocationIcon;
