import React from "react";

const CircleIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="48.984"
      height="49.008"
      viewBox="0 0 48.984 49.008"
    >
      <path
        id="shape"
        d="M0,24.493A24.618,24.618,0,0,1,24.493,0,24.633,24.633,0,0,1,48.984,24.493,24.638,24.638,0,0,1,24.493,49.008,24.638,24.638,0,0,1,0,24.493Z"
        fill="#fa1e0e"
      />
    </svg>
  );
};

export default CircleIcon;
