import React from "react";

const EnergyIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="23.438"
      height="36.316"
      viewBox="0 0 23.438 36.316"
    >
      <path
        id="shape"
        d="M5.672,34.314,10.265,21.97H1.25A1.183,1.183,0,0,1,0,20.783a1.745,1.745,0,0,1,.437-1.094L15.406.72C16.563-.749,18.422.2,17.766,2l-4.595,12.36h9.016a1.183,1.183,0,0,1,1.25,1.187A1.813,1.813,0,0,1,23,16.642L8.032,35.6a1.69,1.69,0,0,1-1.3.72C5.892,36.315,5.229,35.5,5.672,34.314Z"
        transform="translate(0 0)"
        fill="#fff"
      />
    </svg>
  );
};

export default EnergyIcon;
