import React from 'react'

const HyEthIcon = () => {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      width='56'
      height='56'
      viewBox='0 0 56 56'
    >
      <defs>
        <clipPath id='clip-path'>
          <rect id='frame' width='56' height='56' rx='28' fill='#fff' />
        </clipPath>
      </defs>
      <g id='black_pink' clipPath='url(#clip-path)'>
        <g
          id='Group_18_Copy'
          data-name='Group 18 Copy'
          transform='translate(7 7)'
        >
          <g id='Group_Copy_15' data-name='Group Copy 15'>
            <rect id='Rectangle' width='42' height='42' fill='none' />
            <path
              id='Combined_Shape'
              data-name='Combined Shape'
              d='M17.5,0A17.5,17.5,0,1,1,0,17.5,17.5,17.5,0,0,1,17.5,0Z'
              transform='translate(3.5 3.5)'
              fill='#464a75'
            />
            <path
              id='Shape'
              d='M0,13.9l7.516,4.44L15.04,13.9,7.517,24.5Zm.113-1.427L7.632,0l7.517,12.482L7.631,16.923Z'
              transform='translate(13.422 8.75)'
              fill='#fff'
            />
          </g>
        </g>
      </g>
    </svg>
  )
}

export default HyEthIcon
