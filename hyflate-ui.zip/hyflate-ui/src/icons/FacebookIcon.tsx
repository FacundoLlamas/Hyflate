import React from "react";

const FacebookIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="32"
      height="32"
      viewBox="0 0 32 32"
    >
      <g id="Group" opacity="0.6">
        <rect id="Rectangle" width="32" height="32" fill="none" />
        <path
          id="Fill_1"
          data-name="Fill 1"
          d="M26.667,13.333A13.333,13.333,0,1,0,11.25,26.5V17.188H7.865V13.333H11.25V10.4c0-3.342,1.991-5.187,5.036-5.187a20.5,20.5,0,0,1,2.985.26V8.75H17.59a1.927,1.927,0,0,0-2.173,2.082v2.5h3.7l-.591,3.854H15.417V26.5a13.337,13.337,0,0,0,11.25-13.171"
          transform="translate(2.667 2.667)"
          fill="#141029"
        />
      </g>
    </svg>
  );
};

export default FacebookIcon;
