import React from "react";

const ArrowRightIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g id="arrow_right" opacity="0.6">
        <rect id="frame" width="24" height="24" fill="none" />
        <path
          id="shape"
          d="M8.867,12.336a.983.983,0,0,0,.7-.312L14.7,6.914a1.067,1.067,0,0,0,.313-.742A1.053,1.053,0,0,0,14.7,5.43L9.586.32A1.008,1.008,0,0,0,8.867,0a.941.941,0,0,0-.984.953,1.014,1.014,0,0,0,.3.719L9.961,3.453l1.977,1.813L10.18,5.172H1.031A.964.964,0,0,0,0,6.172a.964.964,0,0,0,1.031,1H10.18l1.758-.1L9.961,8.891,8.188,10.664a1.014,1.014,0,0,0-.3.719A.936.936,0,0,0,8.867,12.336Z"
          transform="translate(4.496 6.172)"
          fill="#140129"
        />
      </g>
    </svg>
  );
};

export default ArrowRightIcon;
