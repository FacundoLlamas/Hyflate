import React from "react";

const MenuIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g id="menu" opacity="0.8">
        <rect id="frame" width="24" height="24" fill="none" />
        <path
          id="shape"
          d="M.8,8.915A.83.83,0,0,1,0,8.086a.812.812,0,0,1,.8-.82H15.4a.807.807,0,0,1,.8.82.824.824,0,0,1-.8.829Zm0-3.641a.822.822,0,0,1-.8-.82.812.812,0,0,1,.8-.821H15.4a.807.807,0,0,1,.8.821.816.816,0,0,1-.8.82Zm0-3.632A.822.822,0,0,1,0,.82.812.812,0,0,1,.8,0H15.4a.807.807,0,0,1,.8.82.817.817,0,0,1-.8.821Z"
          transform="translate(3.898 7.914)"
          fill="#141029"
        />
      </g>
    </svg>
  );
};

export default MenuIcon;
