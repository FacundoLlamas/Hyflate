import React from "react";

const CloseIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g id="close" opacity="0.24">
        <rect id="frame" width="24" height="24" fill="none" />
        <path
          id="shape"
          d="M12.461,12.464A1.05,1.05,0,0,0,12.469,11L7.852,6.386l4.617-4.625A1.042,1.042,0,0,0,12.461.3,1.05,1.05,0,0,0,11,.292L6.383,4.909,1.758.292A1.05,1.05,0,0,0,.3.3,1.057,1.057,0,0,0,.289,1.761L4.906,6.386.289,11A1.057,1.057,0,0,0,.3,12.464a1.065,1.065,0,0,0,1.461.016L6.383,7.854,11,12.472A1.05,1.05,0,0,0,12.461,12.464Z"
          transform="translate(5.617 5.989)"
          fill="#141029"
        />
      </g>
    </svg>
  );
};

export default CloseIcon;
