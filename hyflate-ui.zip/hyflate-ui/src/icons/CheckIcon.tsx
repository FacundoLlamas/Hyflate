import React from "react";

const CheckIcon = () => {
  return (
    <svg
      id="check"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 16 16"
    >
      <rect id="frame" width="16" height="16" fill="none" />
      <path
        id="shape"
        d="M3.413,8.584A.777.777,0,0,0,4.1,8.228l4.57-7.051A.873.873,0,0,0,8.833.688.671.671,0,0,0,8.13,0,.656.656,0,0,0,7.5.371l-4.111,6.5-2.1-2.646a.7.7,0,0,0-.581-.293.681.681,0,0,0-.713.7.764.764,0,0,0,.21.518l2.524,3.1A.823.823,0,0,0,3.413,8.584Z"
        transform="translate(3.583 4.28)"
        fill="#fa1e0e"
      />
    </svg>
  );
};

export default CheckIcon;
