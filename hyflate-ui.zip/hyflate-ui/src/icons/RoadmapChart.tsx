import React from 'react'

const RoadmapChart = ({ className }: { className?: string }) => {
  return (
    <svg
      className={className}
      id="Group_1"
      data-name="Group 1"
      xmlns="http://www.w3.org/2000/svg"
      width="1440"
      height="572"
      viewBox="0 0 1440 572"
    >
      <defs>
        <clipPath id="clip-path">
          <rect id="frame" width="1440" height="572" fill="#fff" />
        </clipPath>
        <linearGradient
          id="linear-gradient"
          x2="1"
          y2="1"
          gradientUnits="objectBoundingBox"
        >
          <stop offset="0" stopColor="#fa1e0e" />
          <stop offset="1" stopColor="#8c0000" />
        </linearGradient>
      </defs>
      <g id="chart">
        <g id="chart-2" data-name="chart" clipPath="url(#clip-path)">
          <path
            id="line"
            d="M0,578.354s58.709,1.809,120.127-63.185S243.6,453.9,356.036,480.576,504.281,429.15,553.067,372.788s77.477-93.92,135.039-79.094,120.043,105.832,200.06-58.538,142.879-25.332,253.461-130.475S1329.576,88.436,1436.108,0"
            transform="translate(0 -2)"
            fill="none"
            stroke="#707070"
            strokeLinecap="round"
            strokeMiterlimit="10"
            strokeWidth="8"
          />
        </g>
      </g>
      <g id="q2" transform="translate(1060 96)">
        <text
          id="num"
          transform="translate(0 113)"
          fill="#140129"
          fontSize="24"
          fontFamily="Montserrat-Medium, Montserrat"
          fontWeight="500"
          letterSpacing="-0.042em"
          opacity="0.8"
        >
          <tspan x="0" y="0">
            Q3 2021
          </tspan>
        </text>
        <g id="item" transform="translate(8)">
          <g
            id="surface"
            fill="none"
            stroke="#fff"
            strokeMiterlimit="10"
            strokeWidth="8"
          >
            <rect width="64" height="64" rx="32" stroke="none" />
            <rect x="-4" y="-4" width="72" height="72" rx="36" fill="none" />
          </g>
          <g id="surface-2" data-name="surface">
            <rect
              id="surface-3"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="url(#linear-gradient)"
            />
            <rect
              id="surface-4"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
            <rect
              id="surface-5"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
            <rect
              id="surface-6"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
            <rect
              id="surface-7"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
          </g>
          <g id="feature" transform="translate(8 8)">
            <rect
              id="frame-2"
              data-name="frame"
              width="48"
              height="48"
              fill="none"
            />
            <path
              id="shape"
              d="M5.328,29.547C1.859,29.547,0,27.7,0,24.25V5.281C0,1.844,1.859,0,5.328,0H24.2c3.485,0,5.344,1.844,5.344,5.281V24.25c0,3.438-1.859,5.3-5.344,5.3Z"
              transform="translate(9.227 8.969)"
              fill="#fff"
            />
          </g>
        </g>
      </g>
      <g id="q1" transform="translate(301 383)">
        <g id="item-2" data-name="item" transform="translate(7 59)">
          <g
            id="surface-8"
            data-name="surface"
            fill="none"
            stroke="#fff"
            strokeMiterlimit="10"
            strokeWidth="8"
          >
            <rect width="64" height="64" rx="32" stroke="none" />
            <rect x="-4" y="-4" width="72" height="72" rx="36" fill="none" />
          </g>
          <g id="surface-9" data-name="surface">
            <rect
              id="surface-10"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="url(#linear-gradient)"
            />
            <rect
              id="surface-11"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
            <rect
              id="surface-12"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
            <rect
              id="surface-13"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
            <rect
              id="surface-14"
              data-name="surface"
              width="64"
              height="64"
              rx="32"
              fill="none"
            />
          </g>
          <g id="bolt" transform="translate(8 8)">
            <rect
              id="frame-3"
              data-name="frame"
              width="48"
              height="48"
              fill="none"
            />
            <path
              id="shape-2"
              data-name="shape"
              d="M5.672,34.314,10.265,21.97H1.25A1.183,1.183,0,0,1,0,20.783a1.745,1.745,0,0,1,.437-1.094L15.406.72C16.563-.749,18.422.2,17.766,2l-4.595,12.36h9.016a1.183,1.183,0,0,1,1.25,1.187A1.813,1.813,0,0,1,23,16.642L8.032,35.6a1.69,1.69,0,0,1-1.3.72C5.892,36.315,5.229,35.5,5.672,34.314Z"
              transform="translate(12.281 5.436)"
              fill="#fff"
            />
          </g>
        </g>
        <text
          id="num-2"
          data-name="num"
          transform="translate(0 25)"
          fill="#140129"
          fontSize="24"
          fontFamily="Montserrat-Medium, Montserrat"
          fontWeight="500"
          letterSpacing="-0.042em"
          opacity="0.8"
        >
          <tspan x="0" y="0">
            Q1 2019
          </tspan>
        </text>
      </g>
    </svg>
  )
}

export default RoadmapChart
