import React from 'react'

const PlusIcon = () => {
  return (
    <svg
      className="plus-icon"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g id="plus" opacity="0.4">
        <rect id="frame" width="24" height="24" fill="none" />
        <path
          id="shape"
          d="M6.609,13.406a1.05,1.05,0,0,0,1.039-1.016V7.742H12.2a1.039,1.039,0,0,0,0-2.078H7.648V1.016a1.035,1.035,0,0,0-2.07,0V5.664H1.023a1.039,1.039,0,0,0,0,2.078H5.578v4.648A1.048,1.048,0,0,0,6.609,13.406Z"
          transform="translate(5.387 5.664)"
          fill="#141029"
        />
      </g>
    </svg>
  )
}

export default PlusIcon
