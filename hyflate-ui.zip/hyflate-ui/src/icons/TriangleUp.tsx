import React from "react";

const TriangleUp = () => {
  return (
    <svg
      id="triangle_up_f"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 16 16"
    >
      <rect id="frame" width="16" height="16" fill="none" />
      <path
        id="shape"
        d="M.845,8.091l6.182,0a.756.756,0,0,0,.845-.737,1.5,1.5,0,0,0-.21-.649L4.741.64C4.521.19,4.272,0,3.936,0S3.35.19,3.13.64L.21,6.7A1.521,1.521,0,0,0,0,7.349.76.76,0,0,0,.845,8.091Z"
        transform="translate(4.064 4.437)"
        fill="#00b8b9"
      />
    </svg>
  );
};

export default TriangleUp;
