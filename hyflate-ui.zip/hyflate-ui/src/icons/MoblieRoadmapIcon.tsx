import React from "react";

const MoblieRoadmapIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="360"
      height="64"
      viewBox="0 0 360 64"
    >
      <defs>
        <linearGradient
          id="linear-gradient"
          x1="0.968"
          y1="0.051"
          x2="0.074"
          y2="0.31"
          gradientUnits="objectBoundingBox"
        >
          <stop offset="0" stop-color="#fa1e0e" stop-opacity="0" />
          <stop offset="0.529" stop-color="#fa1e0e" />
          <stop offset="1" stop-color="#fa1e0e" stop-opacity="0" />
        </linearGradient>
        <linearGradient
          id="linear-gradient-2"
          x2="1"
          y2="1"
          gradientUnits="objectBoundingBox"
        >
          <stop offset="0" stop-color="#fa1e0e" />
          <stop offset="1" stop-color="#8c0000" />
        </linearGradient>
      </defs>
      <g id="item" transform="translate(0 8)">
        <rect
          id="surface"
          width="360"
          height="8"
          transform="translate(0 20)"
          fill="url(#linear-gradient)"
        />
        <g id="item-2" data-name="item" transform="translate(156)">
          <g
            id="surface-2"
            data-name="surface"
            fill="none"
            stroke="#fff"
            stroke-miterlimit="10"
            stroke-width="8"
          >
            <rect width="48" height="48" rx="24" stroke="none" />
            <rect x="-4" y="-4" width="56" height="56" rx="28" fill="none" />
          </g>
          <g id="surface-3" data-name="surface">
            <rect
              id="surface-4"
              data-name="surface"
              width="48"
              height="48"
              rx="24"
              fill="url(#linear-gradient-2)"
            />
            <rect
              id="surface-5"
              data-name="surface"
              width="48"
              height="48"
              rx="24"
              fill="none"
            />
            <rect
              id="surface-6"
              data-name="surface"
              width="48"
              height="48"
              rx="24"
              fill="none"
            />
            <rect
              id="surface-7"
              data-name="surface"
              width="48"
              height="48"
              rx="24"
              fill="none"
            />
            <rect
              id="surface-8"
              data-name="surface"
              width="48"
              height="48"
              rx="24"
              fill="none"
            />
          </g>
        </g>
      </g>
    </svg>
  );
};

export default MoblieRoadmapIcon;
