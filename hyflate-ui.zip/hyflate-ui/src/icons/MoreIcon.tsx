import React from "react";

const MoreIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g
        id="round-expand_more-24px"
        transform="translate(0 24) rotate(-90)"
        opacity="0.6"
      >
        <path id="Path" d="M24,24H0V0H24Z" fill="none" opacity="0.87" />
        <path
          id="Path-2"
          data-name="Path"
          d="M5.582,4.173,1.7.292A1,1,0,0,0,.292,1.7l4.59,4.59a1,1,0,0,0,1.41,0l4.59-4.59a1,1,0,0,0,0-1.41,1.017,1.017,0,0,0-1.42,0Z"
          transform="translate(6.418 8.998)"
          fill="#fff"
        />
      </g>
    </svg>
  );
};

export default MoreIcon;
