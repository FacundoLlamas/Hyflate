import React from "react";

const ArrowLeftIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g id="arrow_left" opacity="0.6">
        <rect id="frame" width="24" height="24" fill="none" />
        <path
          id="shape"
          d="M6.141,12.336a.936.936,0,0,0,.984-.953,1.014,1.014,0,0,0-.3-.719L5.055,8.891,3.07,7.07l1.758.1h9.156a.962.962,0,0,0,1.023-1,.962.962,0,0,0-1.023-1H4.828L3.07,5.266,5.055,3.453,6.82,1.672a.983.983,0,0,0,.3-.719A.941.941,0,0,0,6.141,0a1.021,1.021,0,0,0-.719.32L.313,5.43A1.053,1.053,0,0,0,0,6.172a1.067,1.067,0,0,0,.313.742l5.125,5.109A.983.983,0,0,0,6.141,12.336Z"
          transform="translate(4.496 6.172)"
          fill="#140129"
        />
      </g>
    </svg>
  );
};

export default ArrowLeftIcon;
