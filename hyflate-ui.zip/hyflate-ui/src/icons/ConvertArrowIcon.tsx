import React from 'react'

const ConvertArrowIcon = () => {
  return (
    <svg
      className="convert-arrow"
      xmlns="http://www.w3.org/2000/svg"
      width="33"
      height="33"
      viewBox="0 0 33 33"
    >
      <defs>
        <linearGradient
          id="linear-gradient"
          x2="1"
          y2="1"
          gradientUnits="objectBoundingBox"
        >
          <stop offset="0" stopColor="#fff" />
          <stop offset="0.518" stopColor="#fafbfc" />
          <stop offset="1" stopColor="#f5f7fa" />
        </linearGradient>
      </defs>
      <g
        id="Group_11_Copy"
        data-name="Group 11 Copy"
        transform="translate(32.5 0.5) rotate(90)"
      >
        <g id="Oval">
          <circle
            id="Oval-2"
            data-name="Oval"
            cx="16"
            cy="16"
            r="16"
            fill="url(#linear-gradient)"
          />
          <circle
            id="Oval-3"
            data-name="Oval"
            cx="16"
            cy="16"
            r="16"
            fill="none"
          />
          <circle
            id="Oval-4"
            data-name="Oval"
            cx="16"
            cy="16"
            r="16"
            fill="none"
          />
          <circle
            id="Oval-5"
            data-name="Oval"
            cx="16"
            cy="16"
            r="16"
            fill="none"
            stroke="rgba(20,1,41,0.12)"
            strokeMiterlimit="10"
            strokeWidth="1"
          />
        </g>
        <g
          id="round-arrow_downward-24px_1_"
          data-name="round-arrow_downward-24px (1)"
          transform="translate(7.111 24.889) rotate(-90)"
        >
          <path id="Path" d="M0,0H17.778V17.778H0Z" fill="none" />
          <path
            id="Path-2"
            data-name="Path"
            d="M4.883.741V9.015L1.269,5.4a.747.747,0,0,0-1.052,0,.738.738,0,0,0,0,1.044L5.1,11.326a.738.738,0,0,0,1.044,0l4.881-4.881A.739.739,0,0,0,9.98,5.4L6.365,9.015V.741a.741.741,0,0,0-1.481,0Z"
            transform="translate(3.265 2.963)"
            fill="rgba(20,16,41,0.4)"
          />
        </g>
      </g>
    </svg>
  )
}

export default ConvertArrowIcon
