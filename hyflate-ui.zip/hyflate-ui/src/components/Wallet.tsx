import React from 'react'
import { Col, Container, Row, Button } from 'react-bootstrap'
import { LinkContainer } from 'react-router-bootstrap'

const Wallet = () => {
  return (
    <div className="wallet-section">
      <Container>
        <Row>
          <Col md="6">
            <div className="col-inner text-side">
              <div className="section-heading">
                <p className="heading-ind">enjoy 0% management fees</p>
                <h1 className="heading-text">
                  Inflate Your Wallet Right Now 💸
                </h1>
              </div>
              <p className="p1">Navigate your wealth through every market</p>
              <div className="btns-after">
                <LinkContainer to="dashboard">
                  <Button variant="danger">Try Our Exchange</Button>
                </LinkContainer>
                <Button variant="light" className="text-danger">
                  Whitepaper
                </Button>
              </div>
            </div>
          </Col>
          <Col md="6">
            <div className="hero-img-side text-center mt-3">
              <span className="d-inline-block position-relative">
                <img src="img/image copy 2.png" alt="" />

                <img
                  className="crypto-icon icon-1"
                  src="img/icon-1.png"
                  alt=""
                />
                <img
                  className="crypto-icon minter-icon"
                  src="img/minter-icon.png"
                  alt=""
                />
                <img
                  className="crypto-icon neo-icon"
                  src="img/neo-icon.png"
                  alt=""
                />
                <img
                  className="crypto-icon btc-icon"
                  src="img/btc-icon.png"
                  alt=""
                />
                <img
                  className="crypto-icon ethereum-icon"
                  src="img/ethereum-icon.png"
                  alt=""
                />
                <img
                  className="crypto-icon icon-2"
                  src="img/icon-2.png"
                  alt=""
                />
              </span>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Wallet
