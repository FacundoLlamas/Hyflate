import React from 'react'

const TokenPriceLabel = ({ oneTokenPrice }: { oneTokenPrice: number }) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}
    >
      <span className="amount">
        {oneTokenPrice > 0 ? oneTokenPrice : '----'}
      </span>
      <span className="crun-postf">USD</span>
    </div>
  )
}

export default TokenPriceLabel