import React from 'react'

export const SelectOption = ({ name, img }: { name: string; img: string }) => {
  return (
    <>
      <span>
        {' '}
        <img
          src={img}
          alt={`token-${name}`}
          style={{ height: '20px', width: '16px' }}
        />{' '}
        {name}
      </span>
    </>
  )
}
