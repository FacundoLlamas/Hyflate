import React from 'react'
import Slider from 'react-slick'
// Import css files
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
const BrandSlider = () => {
  const settings = {
    slidesToShow: 5,
    slidesToScroll: 1,
    // centerPadding: "20",
    centerPadding: '70px',
    dots: true,
    centerMode: true,
    autoplay: true,
    responsive: [
      {
        breakpoint: 1050,
        settings: {
          arrows: false,
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 500,
        settings: {
          arrows: false,
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 400,
        settings: {
          arrows: false,
          slidesToShow: 1,
          centerPadding: '40px',
        },
      },
    ],
  }
  return (
    <div className="slider-container pb-3 pt-3 pt-sm-5 position-relative">
      <img className="bg-slider" src="img/surface.png" alt="" />
      <Slider className="brand-slider" {...settings}>
        <div>
          <div className="bl-container">
            <img src="img/booongo.svg" alt="" />
          </div>
        </div>
        <div>
          <div className="bl-container">
            <img src="img/push_gaming.svg" alt="" />
          </div>
        </div>
        <div>
          <div className="bl-container">
            <img src="img/image copy 8.svg" alt="" />
          </div>
        </div>
        <div>
          <div className="bl-container">
            <img src="img/booongo.svg" alt="" />
          </div>
        </div>
        <div>
          <div className="bl-container">
            <img src="img/push_gaming.svg" alt="" />
          </div>
        </div>
        <div>
          <div className="bl-container">
            <img src="img/image copy 8.svg" alt="" />
          </div>
        </div>
      </Slider>
    </div>
  )
}

export default BrandSlider
