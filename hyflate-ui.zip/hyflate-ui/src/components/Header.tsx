import React from 'react'
import { Container, Nav, Navbar, Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { LinkContainer } from 'react-router-bootstrap'
const Header = () => {
  return (
    <Navbar expand="lg" style={{ justifyContent: 'center' }}>
      <Container
        className="position-relative"
        style={{ marginLeft: '2%', marginRight: '2%', width: '100%' }}
      >
        <img className="surface-icon-header" src="img/surface.png" alt="" />

        <Navbar.Brand>
          <Link to="/">
            <img src="img/logo.svg" alt="" />
          </Link>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto" style={{ width: '82%' }}>
            <Nav.Link href="#">About us</Nav.Link>
            <Nav.Link href="#link">Strategies</Nav.Link>
            <Nav.Link href="#">Road map</Nav.Link>
            <Nav.Link href="#"> Contact</Nav.Link>
          </Nav>
          <LinkContainer
            style={{
              boxShadow: '0 4px 16px rgb(250 30 14 / 12%)',
              color: 'white',
              width: '180px',
            }}
            to="dashboard"
          >
            <Button variant="danger">Go to Exchange</Button>
          </LinkContainer>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default Header
