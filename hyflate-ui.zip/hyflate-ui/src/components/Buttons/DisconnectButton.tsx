import React from 'react'
import { Button } from 'react-bootstrap'

const DisconnectButton = ({ onClick }: { onClick: () => void }) => {
  return (
    <div>
      <Button variant="danger" size="sm" onClick={onClick}>
        Disconnect
      </Button>
    </div>
  )
}

export default DisconnectButton
