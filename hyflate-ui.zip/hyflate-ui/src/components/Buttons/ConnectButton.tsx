import React from 'react'
import { Button } from 'react-bootstrap'

const ConnectButton = ({
  disabled,
  onClick,
}: {
  disabled: boolean
  onClick: () => void
}) => {
  return (
    <>
      <Button variant="danger" size="sm" disabled={disabled} onClick={onClick}>
        Connect to Metamask
        {'  '}
        <img
          style={{ width: '20px', height: '20px' }}
          src="./img/icons/metamaskFox.svg"
          alt="metamask"
        />
      </Button>
    </>
  )
}

export default ConnectButton
