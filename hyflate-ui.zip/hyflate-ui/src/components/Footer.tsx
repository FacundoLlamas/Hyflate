import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import LocationIcon from '../icons/LocationIcon'
import MessageIcon from '../icons/MessageIcon'

const Footer = () => {
  return (
    <footer>
      <Container>
        <Row>
          <Col md={6}>
            <h2 className="footer-brand-heading font-weight-bold">HyFlate</h2>
            <ul className="list-unstyled">
              <li>
                <a href="#f">
                  <LocationIcon />
                  <span>United States</span>
                </a>
              </li>
              <li>
                <a href="#e">
                  <MessageIcon />
                  <span>English (United States)</span>
                </a>
              </li>
              <li className="d-none d-md-block">
                <span>© 2021 Hyflate</span>
              </li>
            </ul>
          </Col>
          <Col className="px-0 d-flex flex-wrap" md={6}>
            <Col md={4} sm={6} xs={6}>
              <h3>company</h3>
              <ul className="list-unstyled">
                <li>
                  <a href="#a">Home</a>
                </li>
                <li>
                  <a href="#a">About us</a>
                </li>
                <li>
                  <a href="#a">Strategies</a>
                </li>
                <li>
                  <a href="#a">Road map</a>
                </li>
              </ul>
            </Col>
            <Col md={4} sm={6} xs={6}>
              <h3>Other</h3>
              <ul className="list-unstyled">
                <li>
                  <a href="#a">Documentation</a>
                </li>
                <li>
                  <a href="#a">FAQ</a>
                </li>
                <li>
                  <a href="#a">Term of use</a>
                </li>
                <li>
                  <a href="#a">Privacy & terms</a>
                </li>
              </ul>
            </Col>
            <Col md={4} sm={6} xs={6}>
              <div className="d-inline-block text-right">
                <h3 className="text-left">Follow</h3>
                <ul className="text-left list-unstyled mb-0">
                  <li>
                    <a href="#a">Facebook</a>
                  </li>
                  <li>
                    <a href="#a">Instagram</a>
                  </li>
                  <li>
                    <a href="#a">Youtube</a>
                  </li>
                  <li>
                    <a href="#a">Twitter</a>
                  </li>
                  <li className="d-block d-md-none pt-4 ">
                    <span className="pl-0 ml-0 mt-2">made by</span>
                    <a href="roobinium.io" className="site-">
                      roobinium.io
                    </a>
                  </li>
                  <li className="d-block d-md-none d-none">
                    <span className="pl-0 ml-0">© 2021 Hyflate</span>
                  </li>
                </ul>
              </div>
            </Col>
          </Col>
        </Row>
      </Container>
    </footer>
  )
}

export default Footer
