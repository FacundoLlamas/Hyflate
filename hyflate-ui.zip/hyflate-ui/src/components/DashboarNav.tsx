import React, { useState, useEffect } from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { useWeb3React } from '@web3-react/core'
import { Web3Provider } from '@ethersproject/providers'
import { formatEther } from '@ethersproject/units'

import { inject } from '../connectors/inject'

import useInactiveListener from '../hooks/useInactiveListener'
import useEagerConnect from '../hooks/useEagerConnect'
import ConnectButton from '../components/Buttons/ConnectButton'
import DisconnectButton from '../components/Buttons/DisconnectButton'
import { useTokensBalance } from '../hooks/useTokensBalance'
import { TOKEN } from '../constants'
import { hashShortener } from '../utils/helpers'

const ERC20TokenBalance = ({ ethBalance }: { ethBalance: string }) => {
  const tokensBalance = useTokensBalance(ethBalance)

  return (
    <>
      {tokensBalance && (
        <div
          style={{ marginRight: '10px' }}
        >{`${tokensBalance} ${TOKEN.symbol}`}</div>
      )}
    </>
  )
}

const DashboarNav = () => {
  const {
    connector,
    library,
    chainId,
    account,
    activate,
    deactivate,
    active,
    error,
  } = useWeb3React<Web3Provider>()

  // handle logic to recognize the connector currently being activated
  const [activatingConnector, setActivatingConnector] = useState<
    typeof connector | undefined
  >()
  const [ethBalance, setEthBalance] = useState<string | null>()

  useEffect(() => {
    if (activatingConnector && activatingConnector === connector) {
      setActivatingConnector(undefined)
    }
  }, [activatingConnector, connector])

  // handle logic to eagerly connect to the injected ethereum provider, if it exists and has granted access already
  const triedEager = useEagerConnect()

  // handle logic to connect in reaction to certain events on the injected ethereum provider, if it exists
  useInactiveListener(!triedEager || !!activatingConnector)

  // fetch eth balance of the connected account
  useEffect(() => {
    if (library && account) {
      const getBalance = async () => {
        try {
          const balance = await library.getBalance(account)

          setEthBalance(parseFloat(formatEther(balance)).toPrecision(5))
        } catch (e) {
          setEthBalance(null)
        }

        return () => {
          setEthBalance(null)
        }
      }
      getBalance()
    }
  }, [library, account, chainId])

  return (
    <Navbar expand="lg">
      <Container className="position-relative">
        <Navbar.Brand>
          <Link to="/">
            <img src="img/logo.svg" alt="" />
          </Link>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link href="#">About us</Nav.Link>
            <Nav.Link href="#link">Strategies</Nav.Link>
            <Nav.Link href="#">Road map</Nav.Link>
            <Nav.Link href="#"> Contact</Nav.Link>
          </Nav>
          <div>
            {!!(library && account && active && ethBalance) ? (
              <div className="dashboardNav_disconnect">
                <div style={{ marginRight: '10px' }}>
                  {hashShortener(account)}
                </div>
                <div style={{ marginRight: '10px' }}>{ethBalance} ETH</div>
                {ethBalance && <ERC20TokenBalance ethBalance={ethBalance} />}
                <DisconnectButton
                  onClick={() => {
                    deactivate()
                    setEthBalance(undefined)
                  }}
                />
              </div>
            ) : (
              <div className="dashboardNav_connect">
                <ConnectButton
                  disabled={!triedEager || connector === inject || !!error}
                  onClick={() => {
                    setActivatingConnector(inject)
                    activate(inject)
                  }}
                />
              </div>
            )}
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default DashboarNav
