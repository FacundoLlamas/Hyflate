import { TOKEN } from '../../constants'
import { SelectOption } from '../SelectOption'
import ethLogo from './ethereum.png'

export enum inputReferences {
  ethInp = 'eth',
  tokenInp = 'token',
}

export const coins = [
  { name: 'ETH', icon: SelectOption({ name: 'ETH', img: ethLogo }) },
]
export const tokens = [
  {
    name: TOKEN.symbol,
    icon: SelectOption({ name: TOKEN.symbol, img: TOKEN.logo }),
  },
]
