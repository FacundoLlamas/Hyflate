import React, { useState, useEffect, useRef } from 'react'
import { Button, Modal } from 'react-bootstrap'
import { AbstractConnector } from '@web3-react/abstract-connector'
import Select from 'react-select'
import CloseIcon from '../icons/CloseIcon'
import GearIcon from '../icons/GearIcon'
import ConvertArrowIcon from '../icons/ConvertArrowIcon'
import ConnectButton from './Buttons/ConnectButton'
import { inject } from './../connectors/inject'
import { inputReferences, coins, tokens } from './common'
import { getPriceForEthAmount, getPriceForTokenQuantity } from '../api'
import { AmountTokensEthPrice } from '../api/interfaces'

const hasInjectedProvider = window.ethereum?.isMetaMask

const SelectPopup = ({
  connected,
  show,
  onHide,
  buyToken,
  error,
  activate,
}: {
  connected: boolean
  show: boolean
  onHide: () => void
  buyToken: (param: string) => void
  error?: string
  activate: (connector: AbstractConnector) => Promise<void>
}) => {
  const [ethAmount, setEthAmount] = useState('')
  const [tokenAmount, setTokenAmount] = useState('')
  const [orderSummary, setOrderSummary] = useState<AmountTokensEthPrice>()
  const touched = useRef('')

  useEffect(() => {
    if (!connected) {
      touched.current = ''
      setOrderSummary(undefined)
    }

    if (ethAmount && touched.current === inputReferences.ethInp) {
      const getTokenPriceForEth = setTimeout(async () => {
        const tokensAmount = await getPriceForEthAmount(ethAmount, touched)

        tokensAmount &&
          setOrderSummary({
            ethTokensPrice: tokensAmount.tokensAmount,
            fee: tokensAmount.fee,
            percent: tokensAmount.percent,
            sum: +ethAmount,
          })
        tokensAmount && setTokenAmount(`${tokensAmount.tokensAmount}`)
      }, 1500)
      return () => clearTimeout(getTokenPriceForEth)
    }

    if (
      tokenAmount &&
      +tokenAmount > 0 &&
      touched.current === inputReferences.tokenInp
    ) {
      const getTokenPriceForQuantity = setTimeout(async () => {
        const priceInEth = await getPriceForTokenQuantity(tokenAmount, touched)

        setOrderSummary(priceInEth)
        priceInEth && setEthAmount(`${priceInEth.sum}`)
      }, 1500)
      return () => clearTimeout(getTokenPriceForQuantity)
    }
  }, [ethAmount, tokenAmount, connected])

  const isClearable = true
  const isSearchable = true

  const triggerFetch = (position: string) => {
    position === inputReferences.ethInp ? setTokenAmount('') : setEthAmount('')
    touched.current = position
    setOrderSummary(undefined)
  }

  // input handlers
  const onEthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEthAmount(e.target.value)
    triggerFetch(inputReferences.ethInp)
  }

  const onTokenChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTokenAmount(e.target.value)
    triggerFetch(inputReferences.tokenInp)
  }

  const colourStyles = {
    option: (
      styles: any,
      {
        data,
        isDisabled,
        isFocused,
        isSelected,
      }: {
        data: any
        isDisabled: boolean
        isFocused: boolean
        isSelected: boolean
      }
    ) => {
      return {
        ...styles,
        backgroundColor: isDisabled ? null : isSelected ? '#FA1E0E' : isFocused,
        ':active': {
          ...styles[':active'],
          backgroundColor: !isDisabled && '#FA1E0E',
        },
      }
    },
  }

  const onClose = () => {
    setEthAmount('')
    setTokenAmount('')
    onHide()
  }

  return (
    <Modal
      animation={false}
      onHide={onHide}
      show={show}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <div className="swap">
        <Modal.Header>
          <div className="swap-header d-flex justify-content-between w-100">
            <h3>Swap</h3>
            <div className="btns-popup">
              <GearIcon />
              <span className="mr-2"></span>
              <span className="pointer" onClick={onClose}>
                <CloseIcon />
              </span>{' '}
            </div>
          </div>
        </Modal.Header>
        <Modal.Body>
          <div className="select-container d-flex justify-content-between row mx-0">
            <div className="col-sm-6 pl-0 pr-0 pr-sm-2">
              <Select
                styles={colourStyles}
                placeholder="Select a coin"
                className="coin-select w-100"
                classNamePrefix="select"
                defaultValue={coins[0]}
                isClearable={isClearable}
                isSearchable={isSearchable}
                name="coin"
                options={coins}
                getOptionLabel={(coin: any) => coin.icon}
                getOptionValue={(coin: any) => coin.name}
              />
            </div>
            <div className="col-sm-6 mt-3 mt-sm-0 pl-0 pl-sm-2 col-6 pr-0">
              <input
                className="text-left text-sm-right"
                type="number"
                id="coinInput"
                placeholder={
                  touched.current === inputReferences.tokenInp && tokenAmount
                    ? 'Loading...'
                    : '0.0'
                }
                value={ethAmount}
                onChange={onEthChange}
              />
            </div>
            <div className="col-sm-12 mt-3 mt-sm-0 pr-0 pr-sm-2  col-6 px-0"></div>
          </div>
          <div className="position-relative">
            <ConvertArrowIcon />
          </div>
          <div className="select-container mt-2 d-flex justify-content-between row mx-0">
            <div className="col-sm-6 pl-0 pr-0 pr-sm-2">
              <Select
                styles={colourStyles}
                placeholder="Select a Token"
                className="coin-select w-100"
                classNamePrefix="select"
                defaultValue={tokens[0]}
                isClearable={isClearable}
                isSearchable={isSearchable}
                name="token"
                options={tokens}
                getOptionLabel={(token: any) => token.icon}
                getOptionValue={(token: any) => token.name}
              />
            </div>
            <div className="col-sm-6 mt-3 mt-sm-0 pl-0 pl-sm-2 col-6 pr-0">
              <input
                className="text-left text-sm-right"
                type="number"
                id="tokenInput"
                placeholder={
                  touched.current === inputReferences.ethInp && ethAmount
                    ? 'Loading...'
                    : '0.0'
                }
                value={tokenAmount}
                onChange={onTokenChange}
              />
            </div>
            <div className="col-sm-12 mt-3 mt-sm-0 pr-0 pr-sm-2  col-6 px-0"></div>
          </div>
        </Modal.Body>
        <div className="modal_footer">
          {connected ? (
            <div style={{ marginBottom: '15px' }}>
              <Button
                disabled={!ethAmount}
                variant="accent"
                onClick={() => ethAmount && buyToken(ethAmount)}
              >
                Buy
              </Button>
            </div>
          ) : (
            <>
              {hasInjectedProvider ? (
                <ConnectButton
                  disabled={false}
                  onClick={() => activate(inject)}
                />
              ) : (
                'Please, install Metamask extension'
              )}
            </>
          )}

          {orderSummary && +tokenAmount > 0 && (
            <div>
              <div>Quantity: {tokenAmount}</div>
              <div>Fee: {orderSummary.fee}</div>
              <div>Slippage: {orderSummary.percent}</div>
              <div>OrderPrice: {orderSummary.sum}</div>
            </div>
          )}
        </div>
      </div>
      {error && (
        <h3 style={{ fontSize: '16px' }} className="text-center">
          {error}
        </h3>
      )}
    </Modal>
  )
}

export default SelectPopup
