import { NetworkConnector } from '@web3-react/network-connector'

const RPC_URLS = {
  1: `${process.env.REACT_APP_INFURA_MAIN_KEY}`,
  3: `${process.env.REACT_APP_INFURA_KEY}`,
  4: `${process.env.REACT_APP_INFURA_RINK_KEY}`,
}

export const network = new NetworkConnector({
  urls: { 1: RPC_URLS[1], 3: RPC_URLS[3], 4: RPC_URLS[4] },
  defaultChainId: 1,
})

export const Networks = {
  MainNet: 1,
  Ropsten: 3,
  Rinkeby: 4,
}

