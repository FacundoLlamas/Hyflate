import React from 'react'
import Web3 from 'web3'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'

import './App.scss'

import Dashboard from './views/Dashboard'
import Homepage from './views/Homepage'
import { TOKEN } from './constants'
import { minABI } from './abi/minAbi'

export const Web3Client = new Web3(
  new Web3.providers.HttpProvider(`${process.env.REACT_APP_INFURA_MAIN_KEY}`)
)
const contract = new Web3Client.eth.Contract(minABI, TOKEN.address, {
  from: `${process.env.REACT_APP_DEFAULT_ACC}`,
})

export const TokenContractContext = React.createContext(contract)

function App() {
  return (
    <div className="App">
      <TokenContractContext.Provider value={contract}>
        <Router>
          <Switch>
            <Route path="/dashboard">
              <Dashboard />
            </Route>
            <Route path="/">
              <Homepage />
            </Route>
          </Switch>
        </Router>
      </TokenContractContext.Provider>
    </div>
  )
}

export default App
