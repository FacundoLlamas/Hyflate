import erc20Logo from './erc20.png'

export interface IERC20 {
  symbol: string
  address: string
  decimals: number
  name: string
  logo: string
}

export const TOKEN: IERC20 = {
  address: '0xAE17B5894b45380469621854b747804dA3150cB8'.toLowerCase(),
  name: 'Hyflate Token',
  symbol: 'HyFLT',
  decimals: 18,
  logo: erc20Logo,
}
