import React from 'react'
import { AxiosResponse } from 'axios'

import { priceApiInstance } from './instances'
import {
  AmountTokensEthPrice,
  PriceEndpointResponse,
  TokensAmountOnRecievedETH,
} from './interfaces'

export const getPriceForTokenQuantity = async (
  amount: string,
  touched: React.MutableRefObject<string>
) => {
  try {
    const { data } = await priceApiInstance.get<
      AmountTokensEthPrice,
      AxiosResponse<AmountTokensEthPrice>
    >(`/tokens/${amount}/buy`)

    touched.current = ''
    return data
  } catch (error: any) {
    console.log(error.message)
  }
}

export const getPriceForEthAmount = async (
  amount: string,
  touched: React.MutableRefObject<string>
) => {
  try {
    const { data } = await priceApiInstance.get<
      TokensAmountOnRecievedETH,
      AxiosResponse<TokensAmountOnRecievedETH>
    >(`/tokens/${amount}/sell`)

    touched.current = ''
    return data
  } catch (error: any) {
    console.log(error.message)
  }
}

export const getUsdTokenPrice = async () => {
  try {
    const { data } = await priceApiInstance.get<
      PriceEndpointResponse,
      AxiosResponse<PriceEndpointResponse>
    >('/')

    return data
  } catch (error: any) {
    console.log(error.message)
  }
}
