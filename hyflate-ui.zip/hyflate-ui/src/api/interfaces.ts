export interface AmountTokensEthPrice {
  ethTokensPrice: number
  fee: number
  percent: number
  sum: number
}

export interface TokensAmountOnRecievedETH {
  tokensAmount: number
  fee: number
  percent: number
}

export interface PriceEndpointResponse {
  price: number
}
