import { useState, useEffect, useMemo, useContext } from 'react'
import { useWeb3React } from '@web3-react/core'
import { Web3Provider } from '@ethersproject/providers'
import { formatEther } from '@ethersproject/units'

import { TokenContractContext } from './../App'
import { Networks } from './../connectors/network'

export const useTokensBalance = (ethBalance: string): string => {
  const [balance, setBalance] = useState('')
  const contract = useContext(TokenContractContext)
  const { account, chainId } = useWeb3React<Web3Provider>()

  useEffect(() => {
    if (!account) return

    if (chainId === Networks.MainNet) {
      const getBalance = async (): Promise<void> => {
        try {
          const result: string = await contract.methods
            .balanceOf(account)
            .call()
          const showBalance = parseFloat(formatEther(result))
          return setBalance(`${showBalance}`)
        } catch (error: any) {
          console.error(error.message)
        }
      }

      getBalance()
    } else {
      setBalance('')
    }
  }, [chainId, account, contract.methods, ethBalance])

  return useMemo(() => balance, [balance])
}
