import React from 'react'
import ReactDOM from 'react-dom'
import { Web3ReactProvider } from '@web3-react/core'
import getLibrary from './utils/getLibrary'

import './custom.scss'
import './index.css'

import App from './App'
import reportWebVitals from './reportWebVitals'

const HyFlate = () => {
  return (
    <Web3ReactProvider getLibrary={getLibrary}>
      <App />
    </Web3ReactProvider>
  )
}

ReactDOM.render(
  <React.StrictMode>
    <HyFlate />
  </React.StrictMode>,
  document.getElementById('root')
)

reportWebVitals()
