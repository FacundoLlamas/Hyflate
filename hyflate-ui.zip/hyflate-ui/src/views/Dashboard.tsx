import React, { Fragment, useState, useEffect } from 'react'
import { Line } from 'react-chartjs-2'
import {
  Accordion,
  Breadcrumb,
  Button,
  Card,
  Col,
  Container,
  Row,
  Table,
} from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import { useWeb3React } from '@web3-react/core'
import { Web3Provider } from '@ethersproject/providers'
import { parseUnits } from '@ethersproject/units'

import DashboarNav from '../components/DashboarNav'
import Footer from '../components/Footer'
import ArrowDownIcon from '../icons/ArrowDownIcon'
import HyEthIcon from '../icons/HyEthIcon'
import MoreIcon from '../icons/MoreIcon'
import TriangleUp from '../icons/TriangleUp'
import SelectPopup from '../components/SelectPopup'
import { getErrorMessage, hashShortener } from '../utils/helpers'
import { getUsdTokenPrice } from '../api'
import TokenPriceLabel from '../components/TokenPriceLabel'

const data = {
  labels: ['01-Jan', '02-Jan', '03-Jan', '04-Jan', '05-Jan', '06-Jan'],
  datasets: [
    {
      label: 'USD',
      data: [12, 19, 3, 5, 2, 3],
      fill: false,
      backgroundColor: '#16B8B8',
      borderColor: '#16B8B8',
    },
  ],
}
const options = {
  scales: {
    yAxes: [
      {
        ticks: {
          beginAtZero: true,
        },
      },
    ],
  },
}

type ConfirmedTx = {
  txHash: string
  confirmed: boolean
}

const Dashboard = () => {
  const [active, setActive] = useState(1)
  const [modalShow, setModalShow] = useState(false)
  const [confirmation, setConfirmation] = useState<ConfirmedTx>()
  const [oneTokenPrice, setOneTokenPrice] = useState(0)
  // bid should be 1% less
  const oneTokenPriceToSell =
    oneTokenPrice > 0 && (oneTokenPrice * 0.99).toFixed(5)

  const { library, account, error, activate } = useWeb3React<Web3Provider>()

  useEffect(() => {
    const getOneTokenPrice = async () => {
      const res = await getUsdTokenPrice()
      if (res) {
        setOneTokenPrice(+res.price.toFixed(5))
      }
    }

    getOneTokenPrice()
  })

  const buyToken = async (value: string) => {
    if (!!(library && account)) {
      setConfirmation(undefined)
      try {
        const tx = await library.getSigner(account).sendTransaction({
          from: account,
          to: `${process.env.REACT_APP_DEFAULT_ACC}`,
          value: parseUnits(value),
        })

        const receipt = await library.waitForTransaction(tx.hash)
        receipt.blockHash &&
          setConfirmation({
            txHash: receipt.transactionHash,
            confirmed: !!receipt.status,
          })
      } catch (error) {
        console.log(getErrorMessage(error))
      }
    }
  }

  return (
    <Fragment>
      <SelectPopup
        show={modalShow}
        onHide={() => setModalShow(false)}
        buyToken={buyToken}
        error={error && getErrorMessage(error)}
        connected={!!(library && account)}
        activate={activate}
      />
      <DashboarNav />
      <div className="dashboard">
        <Container>
          <Breadcrumb className="bg-transparent br-crumb">
            <NavLink to="/">Home</NavLink>
            <MoreIcon />
            <Breadcrumb.Item active>Dashboard</Breadcrumb.Item>
          </Breadcrumb>
          <section className="our-products">
            <h2 className="text-light font-weight-bold">Our Products</h2>
            {error && (
              <h3
                style={{
                  fontSize: '16px',
                }}
                className="text-center text-light font-weight-bold"
              >
                {getErrorMessage(error)}
              </h3>
            )}
            <Accordion className="mt-4" defaultActiveKey="1">
              <div className={`acc ${active === 1 ? 'active' : ''} `}>
                <Accordion.Toggle
                  onClick={() => (active === 1 ? setActive(0) : setActive(1))}
                  className={`accordianHeader ${active === 1 ? 'active' : ''} `}
                  as={Card.Header}
                  eventKey="1"
                >
                  <Row className="align-items-center py-3 px-1">
                    <Col md={3} sm={4}>
                      <div className="coin-box d-flex align-items-center">
                        <HyEthIcon />
                        <div className="coin-name ">
                          <span className="d-block">HY-ETH</span>
                          <span className="d-block">Ticker</span>
                        </div>
                        <span className="d-block d-sm-none ml-auto">
                          <ArrowDownIcon />
                        </span>
                      </div>
                    </Col>
                    <Col md={6} sm={5}>
                      <div className="d-flex justify-content-between my-3 my-sm-0">
                        <div className="graph-headline text-center">
                          <span className="d-block"> 24h</span>
                          <span>
                            <TriangleUp /> 87.5%
                          </span>
                        </div>
                        <div className="graph-headline text-center">
                          <span className="d-block"> 24h</span>
                          <span>
                            <TriangleUp /> 87.5%
                          </span>
                        </div>
                        <div className="graph-headline text-center">
                          <span className="d-block"> 24h</span>
                          <span>
                            <TriangleUp /> 87.5%
                          </span>
                        </div>
                      </div>
                    </Col>
                    <Col
                      md={3}
                      sm={3}
                      className="d-flex justify-content-center justify-content-sm-end text-center"
                    >
                      <div className="head-last-col mr-0 mr-md-2">
                        <div className="coin-name ">
                          <span className="d-block">
                            {oneTokenPrice > 0 ? oneTokenPrice : '----'} USD
                          </span>
                          <span className="d-block">NAV</span>
                        </div>
                      </div>
                      <ArrowDownIcon className="d-none d-sm-block" />
                    </Col>
                  </Row>
                </Accordion.Toggle>
                <Accordion.Collapse eventKey="1">
                  <Card.Body>
                    <div className="description-acc">
                      <h3>Description</h3>
                      <p>
                        Remember to talk about ypur mission. Why are you
                        building this project? Who are you building this for?
                        Who do you care so much about solving this problem? Why
                        should people care?
                      </p>
                    </div>

                    <div className="historic-chat ">
                      <Row>
                        <Col lg={6}>
                          <h3 className="mb-5">Historic Chart</h3>
                          <Line data={data} options={options} />
                        </Col>
                        <Col lg={6} className="mt-lg-0 mt-4">
                          <h3 className="text-center">Sell & Buy</h3>
                          <div className="d-flex contain-sell-buy">
                            <div className="buy-sell-btn">
                              <span className="crun">ASK</span>
                              <TokenPriceLabel oneTokenPrice={oneTokenPrice} />
                              <Button
                                variant="accent"
                                onClick={() => setModalShow(true)}
                              >
                                Buy
                              </Button>
                            </div>
                            <div className="buy-sell-btn">
                              <span className="crun">BID</span>
                              <TokenPriceLabel
                                oneTokenPrice={+oneTokenPriceToSell}
                              />
                              <Button
                                variant="danger"
                                onClick={() => setModalShow(true)}
                              >
                                SELL
                              </Button>
                            </div>
                          </div>
                          <h3 className="text-center my-3 pt-4">
                            Latest Trandes
                          </h3>
                          <Table
                            striped
                            hover
                            responsive
                            className="table-chart"
                          >
                            <thead>
                              <tr>
                                <td>
                                  <span>10/10/2021</span>
                                  <span className="d-block">Date</span>
                                </td>
                                <td>
                                  <span>2.00</span>
                                  <span className="d-block">In</span>
                                </td>
                                <td>
                                  <span>2.01</span>
                                  <span className="d-block">Out</span>
                                </td>
                                <td>
                                  <span className="d-block">5%</span>
                                  <span className="text-accent">Return</span>
                                </td>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <span>10/10/2021</span>
                                  <span className="d-block">Date</span>
                                </td>
                                <td>
                                  <span>2.00</span>
                                  <span className="d-block">In</span>
                                </td>
                                <td>
                                  <span>2.01</span>
                                  <span className="d-block">Out</span>
                                </td>
                                <td>
                                  <span className="d-block">5%</span>
                                  <span className="text-accent">Return</span>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <span>10/10/2021</span>
                                  <span className="d-block">Date</span>
                                </td>
                                <td>
                                  <span>2.00</span>
                                  <span className="d-block">In</span>
                                </td>
                                <td>
                                  <span>2.01</span>
                                  <span className="d-block">Out</span>
                                </td>
                                <td>
                                  <span className="d-block">5%</span>
                                  <span className="text-accent">Return</span>
                                </td>
                              </tr>
                            </tbody>
                          </Table>
                        </Col>
                      </Row>
                    </div>
                  </Card.Body>
                </Accordion.Collapse>
                {confirmation?.confirmed && (
                  <h5 className="text-center text-black font-weight-bold">
                    {`Completed transaction: ${hashShortener(
                      confirmation.txHash
                    )}`}
                  </h5>
                )}
              </div>
              <div className={`acc disabled ${active === 2 ? 'active' : ''}`}>
                <Accordion.Toggle
                  onClick={() => (active === 2 ? setActive(0) : setActive(2))}
                  className={`accordianHeader ${active === 2 ? 'active' : ''} `}
                  as={Card.Header}
                  eventKey=""
                >
                  <div className="accordian-head">
                    <span className="d-block text-center w-100">
                      Comming Soon
                    </span>
                    <ArrowDownIcon></ArrowDownIcon>
                  </div>
                </Accordion.Toggle>
                <Accordion.Collapse eventKey="2">
                  <Card.Body></Card.Body>
                </Accordion.Collapse>
              </div>
            </Accordion>
            <div className="text-light after-acc-p">
              <p>Random Information About Contract</p>
              <p>Some More Information</p>
              <p>ETC.</p>
            </div>
          </section>
        </Container>
      </div>
      <Footer />
    </Fragment>
  )
}

export default Dashboard
