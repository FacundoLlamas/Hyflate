const Q1 = `Deploying the main network. Launch the original 
masterminds. Starting block browser. Starting the user 
console.`
const Q2 = `Deploying the main network. Launch the original 
masterminds. Starting block browser. Starting the user 
console222.`
const Q3 = `Deploying the main network. Launch the original 
masterminds. Starting block browser. Starting the user 
console333.`
const Q4 = `Deploying the main network. Launch the original 
masterminds. Starting block browser. Starting the user 444.`

export const texts = [Q1, Q2, Q3, Q4]
