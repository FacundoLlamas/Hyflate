import React, { Fragment, useState } from 'react'
import {
  Col,
  Container,
  Row,
  Button,
  Accordion,
  Card,
  Form,
} from 'react-bootstrap'
import Slider from 'react-slick'
import BrandSlider from '../components/BrandSlider'
import Wallet from '../components/Wallet'
import CircleIcon from '../icons/CircleIcon'
import ListIcon from '../icons/ListIcon'
import Paperplan from '../icons/Paperplan'
import PersonIcon from '../icons/PersonIcon'
import useWindowDimensions from '../hooks/useWindowDimensions'
import PendingIcon from '../icons/PendingIcon'
import CheckIcon from '../icons/CheckIcon'
import RoadmapChart from '../icons/RoadmapChart'
import ArrowLeftIcon from '../icons/ArrowLeftIcon'
import ArrowRightIcon from '../icons/ArrowRightIcon'

import PlusIcon from '../icons/PlusIcon'
import MinusIcon from '../icons/MinusIcon'
import TelegramIcon from '../icons/TelegramIcon'
import TwitterIcon from '../icons/TwitterIcon'
import FacebookIcon from '../icons/FacebookIcon'
import GitHubIcon from '../icons/GitHubIcon'
import Footer from '../components/Footer'
import Header from '../components/Header'
import { texts } from './constants'

const Homepage = () => {
  const { width } = useWindowDimensions()

  const settings = {
    className: 'center',
    centerMode: true,
    infinite: true,
    centerPadding: '0px',
    slidesToShow: 1,
    speed: 500,
    dots: true,
  }
  const [active, setActive] = useState(1)
  const [quarter, setQuarter] = useState(1)

  const decreaseHandler = () => {
    setQuarter((prev) => prev - 1)
  }
  const increaseHandler = () => {
    setQuarter((prev) => prev + 1)
  }

  return (
    <Fragment>
      <Header />
      <div>
        <Wallet />
        <BrandSlider />
        {/* section-1 */}
        <section className="section-1">
          <Container>
            <Row>
              <Col md={6} className="d-none d-sm-block">
                <div className="vide-poster position-relative text-center">
                  <img
                    src="img/poster.jpg"
                    className="rounded img-fluid"
                    alt=""
                  />
                  <Button className="play-btn" variant="light">
                    <img src="img/play-icon.svg" alt="" />
                    <span>Watch Video</span>
                  </Button>
                </div>
              </Col>
              <Col md={6}>
                <div className="inner-text-less">
                  <div className="section-heading">
                    <p className="heading-ind">enjoy 0% management fees</p>
                    <h1 className="heading-text">
                      About the service in 2 minutes 🎞
                    </h1>
                  </div>
                  <div className="vide-poster position-relative text-center only-mobile d-block d-sm-none">
                    <img
                      src="img/poster.jpg"
                      className="rounded img-fluid"
                      alt=""
                    />
                    <Button className="play-btn" variant="light">
                      <img src="img/play-icon.svg" alt="" />
                      <span>Watch Video</span>
                    </Button>
                  </div>
                  <p className="p1">
                    You can evaluate all the functionality by creating a free
                    account and find the performers you are interested in.
                  </p>
                  <div className="btns-after">
                    <Button variant="danger">Try Now</Button>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </section>

        <section className="section-1 bg-gr">
          <Container className="position-relative">
            <div className="bg-section-right"></div>
            <Row>
              <Col md={6}>
                <div className="inner-text-less">
                  <div className="section-heading">
                    <p className="heading-ind">main goals</p>
                    <h1 className="heading-text">Hyflate Mission ⭐️</h1>
                  </div>
                  <div className="text-center only-mobile d-block d-sm-none">
                    <img
                      src="img/group-poster.jpg"
                      className="rounded img-fluid"
                      alt=""
                    />
                  </div>
                  <p className="p1">
                    Remember to talk about ypur mission. Why are you building
                    this project? Who are you building this for? Who do you care
                    so much about solving this problem? Why should people care?
                  </p>
                  <div className="btns-after">
                    <Button variant="danger">Whitepaper</Button>
                  </div>
                </div>
              </Col>
              <Col md={6}>
                <div className="text-center mt-4 mt-lg-0 d-none d-sm-block">
                  <img
                    src="img/group-poster.jpg"
                    className="rounded img-fluid"
                    alt=""
                  />
                </div>
              </Col>
            </Row>
          </Container>
        </section>

        <section className="section-2">
          <Row>
            <Col lg={6}>
              <img className="img-fluid w-100" src="img/d-1.png" alt="" />
            </Col>
            <Col lg={6} className="bg-red align-self-center my-0 my-md-4">
              <div className="bg-red-inner">
                <div className="section-heading">
                  <p className="heading-ind">try now</p>
                  <h1 className="heading-text">Strategies 💡</h1>
                </div>
                <p className="p1">
                  Here you can put a short description providing more context
                  for the headline
                </p>
                <div className="btns-after">
                  <Button variant="light">Choose a Strategy</Button>
                </div>
              </div>
            </Col>
          </Row>
        </section>

        <section className="section-1 bg-gr">
          <div className="section-heading text-center">
            <p className="heading-ind">features</p>
            <h1 className="heading-text mw-100 mx-auto">
              Platform Best Features 🪁
            </h1>
          </div>
          {width > 767 && (
            <Container className=" position-relative">
              <div className="slider-circle-img"></div>
              <Row>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <ListIcon />
                    </div>
                    <h2 className="feature-heading">Cross-platform rate</h2>
                    <p className="p2">
                      Track the popularity of various performers on each site
                      separately
                    </p>
                  </div>
                </Col>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <PersonIcon />
                    </div>
                    <h2 className="feature-heading">Social analysis</h2>
                    <p className="p2">
                      Identify the most popular artist by the number of
                      followers or comments
                    </p>
                  </div>
                </Col>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <Paperplan />
                    </div>
                    <h2 className="feature-heading">Geography</h2>
                    <p className="p2">
                      You can see the dynamics of the popularity of an artist or
                      a specific track
                    </p>
                  </div>
                </Col>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <CircleIcon />
                    </div>
                    <h2 className="feature-heading">Get in touch</h2>
                    <p className="p2">
                      Get started for free, create an account and try all the
                      benefits now
                    </p>
                  </div>
                </Col>
              </Row>
            </Container>
          )}
          {width < 768 && (
            <Container className=" feature-boxs-slider position-relative">
              <div className="slider-circle-img"></div>
              <Slider {...settings}>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <ListIcon />
                    </div>
                    <h2 className="feature-heading">Cross-platform rate</h2>
                    <p className="p2">
                      Track the popularity of various performers on each site
                      separately
                    </p>
                  </div>
                </Col>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <PersonIcon />
                    </div>
                    <h2 className="feature-heading">Social analysis</h2>
                    <p className="p2">
                      Identify the most popular artist by the number of
                      followers or comments
                    </p>
                  </div>
                </Col>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <Paperplan />
                    </div>
                    <h2 className="feature-heading">Geography</h2>
                    <p className="p2">
                      You can see the dynamics of the popularity of an artist or
                      a specific track
                    </p>
                  </div>
                </Col>
                <Col md="6" lg="3">
                  <div className="feature-box">
                    <div className="feature-icon">
                      <CircleIcon />
                    </div>
                    <h2 className="feature-heading">Get in touch</h2>
                    <p className="p2">
                      Get started for free, create an account and try all the
                      benefits now
                    </p>
                  </div>
                </Col>
              </Slider>
            </Container>
          )}
        </section>

        <section className="section-1 road-map position-relative">
          <RoadmapChart className="roadmap-chart d-none d-md-block" />
          {/* <div className="q-2019">
          <p>Q1 2019</p>
          <div className="q-icon">
            <EnergyIcon />
          </div>
        </div> */}
          <Container>
            <Row>
              <Col md={5} lg={4}>
                <div className="section-heading">
                  <p className="heading-ind">roadmap</p>
                  <h1 className="heading-text">
                    What We’ve Achieved, With More to Come 🔥
                  </h1>
                </div>
              </Col>
              <Col md={7} lg={5}>
                <div className="q-card" style={{ zIndex: 5 }}>
                  <div className="q-card__inner">
                    <div className="q-card__head d-flex">
                      <div className="q-card__icon">
                        <PendingIcon />
                      </div>
                      <div className="q-btn-done">
                        <CheckIcon /> <span className="pl-1">done</span>
                      </div>
                    </div>
                    <div className="q-card__body">
                      <h2>Q{quarter + 1} 2021</h2>
                      <p className="p1">{texts[quarter]}</p>
                    </div>
                  </div>
                  <div className="q-card__btns d-flex justify-content-between">
                    <Button
                      onClick={decreaseHandler}
                      disabled={quarter === 0}
                      variant="light"
                    >
                      <ArrowLeftIcon />
                    </Button>
                    <Button
                      onClick={increaseHandler}
                      disabled={quarter === texts.length - 1}
                      variant="light"
                    >
                      Next <ArrowRightIcon />
                    </Button>
                  </div>
                </div>
              </Col>
            </Row>
            <div className="mobile-roadmap-g d-block d-md-none">
              <div className="circle"></div>
            </div>
          </Container>
        </section>

        <section className="bg-gr section-1 position-relative">
          <div className="faq-circle"></div>
          <div className="section-heading text-center">
            <p className="heading-ind">faq</p>
            <h1 className="heading-text mw-100 mx-auto">
              Friendly Asked Question 👨‍💻
            </h1>
          </div>
          <Container>
            <Row>
              <Col md={6}>
                <Accordion className="mt-4" defaultActiveKey="1">
                  <div className={`acc ${active === 1 ? 'active' : ''} `}>
                    <Accordion.Toggle
                      onClick={() =>
                        active === 1 ? setActive(0) : setActive(1)
                      }
                      className={`accordianHeader ${
                        active === 1 ? 'active' : ''
                      } `}
                      as={Card.Header}
                      eventKey="1"
                    >
                      <div className="accordian-head">
                        <span>How can I upgrade my subscription?</span>
                        <PlusIcon />
                        <MinusIcon />
                      </div>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="1">
                      <Card.Body>
                        Sure! You can test out Webflow on our free plan where
                        you can experiment with 2 projects. Your unhosted
                        projects will have a two-page limit, but you can
                        purchase a site plan on a per-project basis to unlock up
                        to 100 static pages and additional CMS pages.
                      </Card.Body>
                    </Accordion.Collapse>
                  </div>
                  <div className={`acc ${active === 2 ? 'active' : ''}`}>
                    <Accordion.Toggle
                      onClick={() =>
                        active === 2 ? setActive(0) : setActive(2)
                      }
                      className={`accordianHeader ${
                        active === 2 ? 'active' : ''
                      }`}
                      as={Card.Header}
                      eventKey="2"
                    >
                      <div className="accordian-head">
                        <span>Where do I edit my account settings?</span>
                        <PlusIcon />
                        <MinusIcon />
                      </div>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="2">
                      <Card.Body>
                        A project is a website that you build in Webflow. You
                        can publish projects to a webflow.io staging subdomain
                        for free, export the code on a paid plan, or add a site
                        plan to connect your custom domain and unlock hosting
                        features.
                      </Card.Body>
                    </Accordion.Collapse>
                  </div>
                  <div className={`acc ${active === 3 ? 'active' : ''}`}>
                    <Accordion.Toggle
                      onClick={() =>
                        active === 3 ? setActive(0) : setActive(3)
                      }
                      className={`accordianHeader ${
                        active === 3 ? 'active' : ''
                      }`}
                      as={Card.Header}
                      eventKey="3"
                    >
                      <div className="accordian-head">
                        <span>
                          Why is my account balance not being settled?
                        </span>
                        <PlusIcon />
                        <MinusIcon />
                      </div>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="3">
                      <Card.Body>
                        Pro accounts can add their own logo to Client Billing
                        forms and the Editor. Pro accounts can also remove
                        references to Webflow in the source code and form
                        submission emails, and hide the Webflow badge from their
                        staging sites.
                      </Card.Body>
                    </Accordion.Collapse>
                  </div>

                  <div className={`acc ${active === 4 ? 'active' : ''}`}>
                    <Accordion.Toggle
                      onClick={() =>
                        active === 4 ? setActive(0) : setActive(4)
                      }
                      className={`accordianHeader ${
                        active === 4 ? 'active' : ''
                      }`}
                      as={Card.Header}
                      eventKey="4"
                    >
                      <div className="accordian-head">
                        <span>How can I change my email address?</span>
                        <PlusIcon />
                        <MinusIcon />
                      </div>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="4">
                      <Card.Body>
                        Webflow hosting scales automatically to handle millions
                        of concurrent visits. All site plans serve sites through
                        our Amazon's Cloudfront CDN and accelerated using
                        Fastly, loading sites in milliseconds.
                      </Card.Body>
                    </Accordion.Collapse>
                  </div>
                </Accordion>
              </Col>
              <Col md={6}>
                <div className="inner-contact">
                  <h3 className="font-weight-bold">Contact Us</h3>
                  <p className="p2 pb-3 pt-4">
                    Explore the future with us. Feel free to get in touch
                  </p>
                  <Form>
                    <Form.Group controlId="formBasicEmail">
                      <Form.Label>Full name</Form.Label>
                      <Form.Control type="text" placeholder="Enter your name" />
                    </Form.Group>
                    <Form.Group controlId="formBasicEmail">
                      <Form.Label>Email address</Form.Label>
                      <Form.Control type="email" placeholder="Enter email" />
                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                      <Form.Label>Message</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Type your message"
                      />
                    </Form.Group>

                    <div className="text-right pt-2">
                      <Button variant="danger" type="submit">
                        Send a request
                      </Button>
                    </div>
                  </Form>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
        <section className="bg-gr s-section section-1 pt-0">
          <Container>
            <div className="mb-4">
              <h2 className="font-weight-bold text-center">
                Keep Updated by Following Us on Social Media
              </h2>
            </div>
            <ul className="list-unstyled d-flex justify-content-center mb-0">
              <li className="mr-3">
                <a href="#t">
                  <TelegramIcon />
                </a>
              </li>
              <li className="mr-3">
                <a href="#t">
                  <TwitterIcon />
                </a>
              </li>
              <li className="mr-3">
                <a href="#t">
                  <FacebookIcon />
                </a>
              </li>
              <li>
                <a href="#t">
                  <GitHubIcon />
                </a>
              </li>
            </ul>
          </Container>
        </section>

        <Footer />
      </div>
    </Fragment>
  )
}

export default Homepage
